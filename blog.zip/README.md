# [Majalengka Developers](https://majalengkadev.github.io)

Kami membuat workshop belajar php dengan studi kasus membangun blog sederhana.
Dalam pembelajaran ini kami menggunakan template [Clean Blog](http://startbootstrap.com/template-overviews/clean-blog/).
